import './style.css';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

// Setup
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({
  canvas: document.querySelector('#bg'),
});

// Set the initial camera position
camera.position.set(0, 3, 0); // This positions the camera above the origin at a height of 5
camera.lookAt(new THREE.Vector3(0, 0, 0)); // Camera looks at the origin
camera.up.set(0, 1, 0); // Ensures that the camera's up direction is positive y-axis


renderer.setPixelRatio(window.devicePixelRatio);
renderer.setSize(window.innerWidth, window.innerHeight);

// Lights
const pointLight = new THREE.PointLight(0xffffff);
pointLight.position.set(5, 5, 5);
scene.add(pointLight);

// Background
const spaceTexture = new THREE.TextureLoader().load('space.jpg');
spaceTexture.wrapS = spaceTexture.wrapT = THREE.RepeatWrapping; // Enable texture repeating
spaceTexture.repeat.set(5, 5); // Repeat the texture to cover the entire background plane

// Create a large background plane
const backgroundGeometry = new THREE.PlaneGeometry(window.innerWidth, window.innerHeight, 100, 100); // This should cover the camera's view
const backgroundMaterial = new THREE.MeshBasicMaterial({ map: spaceTexture, side: THREE.DoubleSide });
const backgroundMesh = new THREE.Mesh(backgroundGeometry, backgroundMaterial);

// Position it so that it covers the camera view
// The z-position should be negative and far enough away to cover the entire view
backgroundMesh.position.set(0.1, -500, 180);
backgroundMesh.lookAt(camera.position);

// Scale the mesh to cover the entire view. You might need to adjust this depending on your camera settings
const scale = 10; // The scale factor may need to be adjusted
backgroundMesh.scale.set(scale, scale, scale);

scene.add(backgroundMesh);

// GLTF Loader
const loader = new GLTFLoader();
const planeUrl = 'https://rawcdn.githack.com/michzarx/psballs/b4b5b147935a8b15c56b521c6913b8b102e9402a/plane.gltf';
let plane; // This will hold the plane object
let mixer; // This will be our AnimationMixer


// Load a glTF resource
loader.load(planeUrl, function (gltf) {
    plane = gltf.scene;
    scene.add(plane);

    // Rotate the plane 90 degrees to the left around the Y axis
    plane.rotation.y = THREE.MathUtils.degToRad(-270);

    // Adjust the camera to look at the plane
    camera.lookAt(plane.position);

    // AnimationMixer
    mixer = new THREE.AnimationMixer(plane);

    // Play all animations
    gltf.animations.forEach((clip) => {
        const action = mixer.clipAction(clip);
        action.play();
    });

}, undefined, function (error) {
    console.error('An error happened');
});

// Movement variables
let moveUp = false;
let moveDown = false;
let moveLeft = false;
let moveRight = false;

// Event listeners for movement
document.addEventListener('keydown', function(event) {
    switch(event.key) {
        case 'ArrowUp': moveUp = true; break;
        case 'ArrowDown': moveDown = true; break;
        case 'ArrowLeft': moveLeft = true; break;
        case 'ArrowRight': moveRight = true; break;
    }
});

document.addEventListener('keyup', function(event) {
    switch(event.key) {
        case 'ArrowUp': moveUp = false; break;
        case 'ArrowDown': moveDown = false; break;
        case 'ArrowLeft': moveLeft = false; break;
        case 'ArrowRight': moveRight = false; break;
    }
});

// Animation Loop
const clock = new THREE.Clock();
let playAnimation = false;

// Modify the animate function
function animate() {
    requestAnimationFrame(animate);

    // Move the background texture to create the illusion of flying forward
    spaceTexture.offset.y -= 0.004; // Adjust the speed as needed

    // Update any animation mixers or other dynamic elements
    if (mixer) {
        const delta = clock.getDelta();
        mixer.update(delta);
    }

        // Move the plane based on key presses
        if (plane) {
            if (moveUp) plane.position.z -= 0.08;
            if (moveDown) plane.position.z += 0.08;
            if (moveLeft) plane.position.x -= 0.08;
            if (moveRight) plane.position.x += 0.08;
        }

    renderer.render(scene, camera);
}

animate();